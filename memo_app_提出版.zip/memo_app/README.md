# メモ帳アプリ 提出物

| 提出物 | 内容 |
| --- | --- |
| 実行環境一式 | `docker-compose.yml`、`.env.example`、`docker/`、`backend/Dockerfile`、依存パッケージの固定ファイル |
| ソースコード一式 | `frontend/`、`backend/src/`、`htdocs/` |
| 導入・起動手順書 | [導入・起動手順書](docs/導入・起動手順書.md) |
| テスト仕様書 | [テスト仕様書と実行結果](docs/テスト仕様書.md) |
| 簡易マニュアル | [簡易マニュアル](docs/簡易マニュアル.md) |

Docker Composeで起動し、同じPCのブラウザで [メモ帳アプリ](http://localhost:8080/) を開きます。画面はnginx、APIはNode.js／Express、データはMySQLを使用します。リアルタイム同期の確認範囲は同一PC上の別タブです。
